(function(global){
  // Cozy renderer with safe fallbacks and visible probe
  function cssVar(name, fallback){
    try{ const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim(); return v || fallback; }
    catch(_){ return fallback; }
  }
  function drawRoundedRect(ctx,x,y,w,h,r){
    const rr = Math.min(r, w/2, h/2);
    ctx.beginPath();
    ctx.moveTo(x+rr,y); ctx.arcTo(x+w,y,x+w,y+h,rr); ctx.arcTo(x+w,y+h,x,y+h,rr);
    ctx.arcTo(x,y+h,x,y,rr); ctx.arcTo(x,y,x+w,y,rr); ctx.closePath();
  }

  function render(state, ctx, W, H){
    const level = state && state.level;
    const grid = level && level.grid; if(!grid || !grid.length || !grid[0]){
      // Visibly initialize so page isn't blank
      ctx.fillStyle = cssVar('--forest-dark', '#0d2b19'); ctx.fillRect(0,0,W,H);
      // Probe to confirm paint path
      ctx.fillStyle = '#ff00ff'; ctx.fillRect(8,8,8,8);
      return {ts:0,ox:0,oy:0};
    }
    const rows = grid.length, cols = grid[0].length;
    let ts = Math.floor(Math.min(W/cols, H/rows));
    if(!ts || !isFinite(ts)) ts = 8; // clamp
    const ox = Math.floor((W - cols*ts)/2), oy = Math.floor((H - rows*ts)/2);

    // Backdrop
    ctx.fillStyle = cssVar('--forest-dark', '#0d2b19');
    ctx.fillRect(0,0,W,H);

    // Tiles: 1=wall, 0=floor (Maze Forest semantics)
    const soil = cssVar('--soil', '#6f5434');
    const soil2 = '#8a6a3e';
    const stone1 = cssVar('--stone', '#6a755f');
    const stone2 = '#596756';

    for(let r=0;r<rows;r++){
      for(let c=0;c<cols;c++){
        const x = ox + c*ts, y = oy + r*ts;
        if(grid[r][c]===1){
          // stone wall with bevel
          const fill = ((r+c)&1) ? stone1 : stone2;
          ctx.save();
          ctx.shadowColor='rgba(0,0,0,0.35)'; ctx.shadowBlur=Math.max(8, ts*0.25); ctx.shadowOffsetY=Math.max(2, ts*0.12);
          ctx.fillStyle = fill; drawRoundedRect(ctx, x+1, y+1, ts-2, ts-2, Math.max(4, ts*0.18)); ctx.fill();
          ctx.restore();
          // simple bevel highlight
          ctx.fillStyle='rgba(255,255,255,0.08)'; ctx.fillRect(x+2,y+2, ts-4, Math.max(1, ts*0.08));
        } else {
          // warm soil floors (high contrast vs forest backdrop)
          ctx.fillStyle = ((c*73856093 ^ r*19349663) & 8) ? soil : soil2;
          ctx.fillRect(x,y,ts,ts);
        }
      }
    }

    // Exit glow
    const ex = level.exit.x, ey = level.exit.y;
    const cx = ox + ex*ts + ts/2, cy = oy + ey*ts + ts/2;
    const glow = ctx.createRadialGradient(cx,cy, ts*0.1, cx,cy, ts*0.8);
    glow.addColorStop(0, cssVar('--exitGlow','#fff1a8'));
    glow.addColorStop(1, 'rgba(255,241,168,0)');
    ctx.globalCompositeOperation='lighter'; ctx.fillStyle=glow; ctx.fillRect(cx-ts, cy-ts, ts*2, ts*2);
    ctx.globalCompositeOperation='source-over';
    ctx.fillStyle = cssVar('--exit', '#a6f2c1'); drawRoundedRect(ctx, cx-ts*0.3, cy-ts*0.3, ts*0.6, ts*0.6, Math.max(4, ts*0.18)); ctx.fill();

    // Traps
    if(level.traps && level.traps.length){
      for(let i=0;i<level.traps.length;i++){
        const t = level.traps[i]; const x = ox + t.x*ts, y = oy + t.y*ts;
        const active = ((state.ticks + (t.phase||0)) % 60) < 30;
        ctx.save(); ctx.translate(x+ts/2, y+ts/2); ctx.rotate(Math.PI/4);
        ctx.fillStyle = active ? 'rgba(199,165,107,0.95)' : 'rgba(199,165,107,0.45)';
        drawRoundedRect(ctx, -ts*0.28, -ts*0.28, ts*0.56, ts*0.56, Math.max(3, ts*0.12)); ctx.fill();
        ctx.restore();
      }
    }

    // Power-ups
    if(level.powerups && level.powerups.length){
      for(let i=0;i<level.powerups.length;i++){
        const p = level.powerups[i]; const x = ox + p.x*ts, y = oy + p.y*ts;
        const k = p.kind; let col = '#83c8f1';
        if(k==='heal') col = '#8ef0a8'; else if(k==='shield') col = '#9bbcf7';
        const rg = ctx.createRadialGradient(x+ts/2,y+ts/2, ts*0.05, x+ts/2,y+ts/2, ts*0.6);
        rg.addColorStop(0, col); rg.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.globalCompositeOperation='lighter'; ctx.fillStyle=rg; ctx.fillRect(x-ts*0.2,y-ts*0.2,ts*1.4,ts*1.4);
        ctx.globalCompositeOperation='source-over';
        ctx.save(); ctx.shadowColor='rgba(0,0,0,0.35)'; ctx.shadowBlur=Math.max(3, ts*0.12); ctx.shadowOffsetY=Math.max(1, ts*0.08);
        ctx.fillStyle = col; drawRoundedRect(ctx, x+ts*0.18, y+ts*0.18, ts*0.64, ts*0.64, Math.max(4, ts*0.18)); ctx.fill(); ctx.restore();
      }
    }

    // Enemies
    if(level.enemies && level.enemies.length){
      for(let i=0;i<level.enemies.length;i++){
        const e = level.enemies[i]; const x = ox + e.x*ts, y = oy + e.y*ts;
        ctx.save(); ctx.shadowColor='rgba(0,0,0,0.45)'; ctx.shadowBlur=Math.max(4, ts*0.18); ctx.shadowOffsetY=Math.max(2, ts*0.1);
        ctx.fillStyle = cssVar('--red', '#ff4a4a'); drawRoundedRect(ctx, x+ts*0.15, y+ts*0.15, ts*0.7, ts*0.7, Math.max(5, ts*0.22)); ctx.fill();
        ctx.restore();
        ctx.strokeStyle='rgba(0,0,0,0.25)'; ctx.lineWidth=Math.max(1, ts*0.05); ctx.strokeRect(x+ts*0.18, y+ts*0.18, ts*0.64, ts*0.64);
      }
    }

    // Player
    const px = ox + state.player.x*ts, py = oy + state.player.y*ts;
    ctx.save(); ctx.shadowColor='rgba(0,0,0,0.55)'; ctx.shadowBlur=Math.max(4, ts*0.2); ctx.shadowOffsetY=Math.max(2, ts*0.1);
    ctx.fillStyle = cssVar('--blue-ui', '#10a1ff'); drawRoundedRect(ctx, px+2,py+2, ts-4, ts-4, Math.max(4, ts*0.2)); ctx.fill(); ctx.restore();
    ctx.strokeStyle='rgba(255,255,255,0.25)'; ctx.lineWidth=Math.max(1, ts*0.05); ctx.strokeRect(px+3,py+3, ts-6, ts-6);

    // Soft vignette framing
    const vg = ctx.createRadialGradient(W/2,H/2, Math.min(W,H)*0.45, W/2,H/2, Math.min(W,H)*0.9);
    vg.addColorStop(0,'rgba(0,0,0,0)'); vg.addColorStop(1,'rgba(0,0,0,0.4)');
    ctx.fillStyle = vg; ctx.fillRect(0,0,W,H);

    // Debug corner probe
    ctx.fillStyle = '#ff00ff'; ctx.fillRect(8,8,8,8);

    return {ts, ox, oy};
  }

  global.Renderer = { render };
})(window);
