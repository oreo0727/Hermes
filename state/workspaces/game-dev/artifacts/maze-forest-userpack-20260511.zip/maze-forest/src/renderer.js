(function(global){
  const TILE = 20; // base tile size; scaled dynamically to canvas

  function cssVar(name, fallback){
    try{ const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim(); return v || fallback; }
    catch(_){ return fallback; }
  }

  function drawRoundedRect(ctx,x,y,w,h,r){
    const rr = Math.min(r, w/2, h/2);
    ctx.beginPath();
    ctx.moveTo(x+rr,y); ctx.arcTo(x+w,y,x+w,y+h,rr); ctx.arcTo(x+w,y+h,x,y+h,rr);
    ctx.arcTo(x,y+h,x,y,rr); ctx.arcTo(x,y,x+w,y,rr); ctx.closePath();
  }

  function render(state, ctx, w, h){
    // Visible probe to confirm the renderer executed
    ctx.fillStyle = '#ff00ff';
    ctx.fillRect(8,8,8,8);

    // Defensive: verify level/grid presence
    const level = state && state.level;
    const grid = level && level.grid;
    if(!grid || !grid.length || !grid[0]){
      // Paint a safe backdrop so the canvas is clearly initialized
      ctx.fillStyle = cssVar('--grass1', '#6fb26f');
      ctx.fillRect(0,0,w,h);
      return {ts:0, ox:0, oy:0};
    }
    const rows = grid.length, cols = grid[0].length;
    let ts = Math.floor(Math.min(w/cols, h/rows)); if(!ts) ts = 8; // clamp min tile size
    const ox = Math.floor((w - cols*ts)/2); const oy = Math.floor((h - rows*ts)/2);
    try{ console.debug(`Renderer debug: rows=${rows} cols=${cols} ts=${ts} canvas=${w}x${h}`); }catch(_){ }

    // gentle grass backdrop with fallback colors
    ctx.fillStyle = cssVar('--grass1', '#6fb26f');
    ctx.fillRect(0,0,w,h);

    // tiles
    for(let y=0;y<rows;y++){
      for(let x=0;x<cols;x++){
        const gx = ox + x*ts, gy = oy + y*ts;
        if(grid[y][x]===1){
          // tree tile
          ctx.fillStyle = cssVar('--tree', '#315d38');
          drawRoundedRect(ctx, gx+2, gy+2, ts-4, ts-4, 5); ctx.fill();
          ctx.strokeStyle = cssVar('--tree-edge', 'rgba(0,0,0,0.25)');
          ctx.lineWidth = 2; drawRoundedRect(ctx, gx+2, gy+2, ts-4, ts-4, 5); ctx.stroke();
        } else {
          // grass variations
          const c1 = cssVar('--grass1', '#6fb26f');
          const c2 = cssVar('--grass2', '#76bf76');
          ctx.fillStyle = ( (x*73856093 ^ y*19349663) & 8 ) ? c1 : c2; // simple hash pattern
          ctx.fillRect(gx,gy,ts,ts);
        }
      }
    }

    // exit glow
    const ex = level.exit.x, ey = level.exit.y;
    const exx = ox + ex*ts + ts/2, exy = oy + ey*ts + ts/2;
    const grad = ctx.createRadialGradient(exx,exy,2, exx,exy, ts);
    grad.addColorStop(0, 'rgba(166,242,193,0.9)');
    grad.addColorStop(1, 'rgba(166,242,193,0.0)');
    ctx.fillStyle = grad; ctx.beginPath(); ctx.arc(exx,exy, ts*0.75, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = cssVar('--exit', '#e5c970');
    drawRoundedRect(ctx, exx-ts*0.3, exy-ts*0.3, ts*0.6, ts*0.6, 6); ctx.fill();

    // traps
    for(let i=0;i<level.traps.length;i++){
      const t = level.traps[i];
      const gx = ox + t.x*ts, gy = oy + t.y*ts;
      const active = ((state.ticks + (t.phase||0)) % 60) < 30; // on/off
      ctx.save();
      ctx.translate(gx+ts/2, gy+ts/2);
      ctx.rotate((Math.PI/4));
      ctx.fillStyle = active ? 'rgba(199,165,107,0.95)' : 'rgba(199,165,107,0.35)';
      drawRoundedRect(ctx, -ts*0.25, -ts*0.25, ts*0.5, ts*0.5, 3); ctx.fill();
      ctx.restore();
    }

    // power-ups
    for(let i=0;i<level.powerups.length;i++){
      const p = level.powerups[i];
      const gx = ox + p.x*ts, gy = oy + p.y*ts;
      ctx.save(); ctx.translate(gx+ts/2, gy+ts/2);
      if(p.kind==='heal'){ ctx.fillStyle = '#8ef0a8'; }
      else if(p.kind==='shield'){ ctx.fillStyle = '#9bbcf7'; }
      else { ctx.fillStyle = '#83c8f1'; }
      drawRoundedRect(ctx, -ts*0.22, -ts*0.22, ts*0.44, ts*0.44, 5); ctx.fill(); ctx.restore();
    }

    // enemies
    for(let i=0;i<level.enemies.length;i++){
      const e = level.enemies[i];
      const gx = ox + e.x*ts, gy = oy + e.y*ts;
      ctx.fillStyle = cssVar('--enemy', '#3b4d9a');
      ctx.beginPath(); ctx.arc(gx+ts/2, gy+ts/2, ts*0.35, 0, Math.PI*2); ctx.fill();
    }

    // player
    const px = ox + state.player.x*ts, py = oy + state.player.y*ts;
    ctx.fillStyle = '#f5f0d7';
    ctx.beginPath(); ctx.arc(px+ts/2, py+ts/2, ts*0.38, 0, Math.PI*2); ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.2)'; ctx.lineWidth = 2; ctx.stroke();

    return {ts, ox, oy};
  }

  global.Renderer = { render };
})(window);
